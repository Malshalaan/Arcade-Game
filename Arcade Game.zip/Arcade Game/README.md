# Classic Arcade Game Clone Project

## Table of Contents

- [Instructions](#instructions)

## Instructions
1.Download ZIP folder 'Arcade Game'.
2. extract the folder.
3.open the extracted folder .
4.run the index page and enjoy playing arcade game.


